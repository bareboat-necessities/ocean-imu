"""Recompute a measured replay using the binary built from the indicated patch.

Set LD_PRELOAD to the recorded runner libm when reproducing the fixed-draw
numbers with GCC 14.2 on x86-64. Run this file next to scores.csv and the
manifest after unpacking study.tar.gz.
"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile


def file_hash(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'manifest.json').read_text())
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True, type=Path, help='Checkout with the requested simulator built')
    p.add_argument('--data', required=True, type=Path, help='Directory with following and head subdirectories')
    p.add_argument('--family', choices=manifest['binaries'], required=True)
    p.add_argument('--arm', choices=manifest['arms'], required=True)
    p.add_argument('--case', choices=('following','head'), required=True)
    p.add_argument('--record', required=True, help='Exact wave CSV basename')
    p.add_argument('--seed', default='default')
    p.add_argument('--profile', choices=('default','legacy'), default='default')
    args = p.parse_args()
    with (root / 'scores.csv').open() as stream:
        rows = [row for row in csv.DictReader(stream)
                if all(row[k] == getattr(args,k) for k in ('family','arm','case','record','seed','profile'))]
    if len(rows) != 3:
        raise SystemExit('This combination is absent from the recorded experiment')
    source = (args.data / args.case / args.record).resolve()
    if file_hash(source) != manifest['inputs'][args.case][args.record]:
        raise SystemExit(f'Dataset digest differs for {source}')
    spec = manifest['arms'][args.arm]
    env = {k:v for k,v in os.environ.items() if not k.startswith(('W3D_','OCEAN_IMU_','SF_','TFG_','CARMA_'))}
    env.update(W3D_WRITE_TIMESERIES='0', W3D_COLLECT_ALL_GATES='1',
               OCEAN_IMU_SIM_CASE=args.case, W3D_VALIDATION_WINDOW_SEC='900',
               W3D_VALIDATION_SEGMENTS='early:40:60,release:60:150')
    env.update(spec['environment'])
    if args.seed != 'default':
        env['W3D_SEED'] = args.seed
    binary = (args.repo / manifest['binaries'][args.family]).resolve()
    command = [str(binary)]
    if args.profile == 'legacy':
        command.append('--regression')
    command.extend(['--input', str(source)])
    with tempfile.TemporaryDirectory() as tmp:
        result = subprocess.run(command, cwd=tmp, env=env, capture_output=True, text=True)
    print(result.stdout, end='')
    print(result.stderr, end='')
    if result.returncode not in (0,1):
        raise SystemExit(result.returncode)
    actual = {}
    for line in result.stdout.splitlines():
        if line.startswith(('VALIDATION_METRICS ', 'VALIDATION_SEGMENT ')):
            data = dict(token.split('=',1) for token in line.split()[1:])
            actual[data['segment']] = data
    for row in rows:
        data = actual[row['window']]
        if int(data['samples']) != int(row['samples']):
            raise SystemExit('Different number of scored samples')
        for metric in manifest['metrics']:
            calculated, recorded = float(data[metric]), float(row[metric])
            if not math.isclose(calculated, recorded, rel_tol=3e-6, abs_tol=1e-9):
                raise SystemExit(f'{row["window"]} {metric}: measured {calculated}, archived {recorded}')
    if (result.returncode != 0) != (rows[0]['return_code'] != '0'):
        raise SystemExit('Different outcome against the original regression limits')
    print('The three score windows match the archive.')


if __name__ == '__main__':
    main()

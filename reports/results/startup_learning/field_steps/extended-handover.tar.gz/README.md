# Replay of the 72 late production handovers

The existing 35 s study records 888 paired handovers in 960 attempted starts. This extension follows the unmodified OU-III shipping wrappers for 60 s and scores their first live sample. Only the input, loop and completeness limits in the test driver change. The onboard joint learner keeps its original 35 s limit. The extension operates in `--production-pair` mode only.

Use a clean checkout of `ff384db5cdd480f24156cc67c70b0ffc270b956d`, its pinned GCC 14 toolchain and verified v1.4.0 simulation files. Apply `git apply observe-60-seconds.patch`, then run `make -C tests/startup_learning -j1 startup-learning`. For every one of the eight reference CSVs in each of `following` and `head`, invoke the production pair twice, once per cohort. Replace `$record` with the record path and give each output a unique name.

```sh
tests/startup_learning/startup-learning --input "$record" --output "$validation_output" \
  --production-pair --seeds 11,12,13,14,15 --offsets 67,307,607 --profiles calibrated,residual
tests/startup_learning/startup-learning --input "$record" --output "$confirmation_output" \
  --production-pair --seeds 31,32,33,34,35 --offsets 41,191,421 --profiles calibrated,residual
```

Use `(cohort, case, input, profile, seed, offset, method)` as the unique key. Pool an error channel using the square root of the mean squared handover errors. Compare the reported `elapsed_s` against 35. The earlier raw control is `reports/results/startup_learning/field_steps/wave-starts.csv.gz`. Each late record in `late-handovers.csv` contains both the old (`shipping`) and new (`deployed`) policy measurements as separate rows. `joint_seed_applied` records selection in the deployed wrapper. All 1,776 on-time policy rows reproduced the same epoch, raw rate error, gyro-bias error and joint-fit selection. The largest absolute difference in reported yaw was 0.000016 degrees. Inputs, executable, compiler product dependencies and the exact all-row CSV digest are recorded in `inputs.json`. The estimator never receives truth.

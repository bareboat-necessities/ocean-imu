"""Non-promoting paired transition through the low-wave response/noise floor."""
import sys,os,json,hashlib,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent/'ocean-imu';sys.path.insert(0,str(ROOT/'tools'))
import ou_validation as ov
import ou_roundtrip_transition as rt
OUT=BASE/'low-transition';OUT.mkdir(exist_ok=True)
data=ROOT/'tests/kalman_ou_ii'
low=ov.find_default_input(data,'0.270','14.047');high=ov.find_default_input(data,'1.500','50.710')
cols,lo=ov.read_wave_csv(low,1200);_,hi=ov.read_wave_csv(high,1200)
wave=rt.make_roundtrip_wave(ov,cols,lo,hi,60013,1.0)
path=OUT/high.name;ov.write_wave_csv(path,cols,wave)
segments=rt.roundtrip_segments()
def run(t):
 family,seed,scale=t;b=BASE/'final-bin'/('kalman_ou_'+family.lower().split('-')[1]+'-sim');b.chmod(0o755)
 env=dict(os.environ,W3D_WRITE_TIMESERIES='0',W3D_COLLECT_ALL_GATES='1',W3D_VALIDATION_WINDOW_SEC='900',W3D_AW_COV_SYNC='periodic',W3D_IMU_SEED=str(seed),W3D_INIT_SEED=str(seed),SF_LOW_WAVE_RACC_MAX_SCALE=str(scale),W3D_VALIDATION_SEGMENTS=','.join(f'{n}:{a}:{z}' for n,a,z in segments))
 q=subprocess.run([str(b),'--input',str(path)],cwd=b.parent,env=env,capture_output=True,text=True)
 key=f'{family}_{seed}_{scale}';(OUT/(key+'.log')).write_text(q.stdout+q.stderr)
 if q.returncode not in (0,1):raise RuntimeError(q.stderr)
 return dict(family=family,seed=str(seed),config='selected' if scale==4 else 'weighting_off',input=path.name,metrics=ov.parse_validation_metrics(q.stdout),segments=[ov._parse_metric_line(x) for x in q.stdout.splitlines() if x.startswith('VALIDATION_SEGMENT ')],violations=[x for x in (q.stdout+q.stderr).splitlines() if x.startswith('ERROR:')],exit_code=q.returncode)
with ThreadPoolExecutor(4) as pool:rows=list(pool.map(run,[(f,s,c) for f in ['OU-II','OU-III'] for s in [60017,65003] for c in [1,4]]))
(OUT/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps(dict(source_commit='9de0543507509cabb478b751b83bf5c74711764d',protocol='Eight paired O3 replays, Hs .27 -> 1.5 -> .27, 120 s smooth transitions at 400 and 800 s. Kinematically closed surrogate, phase seed 60013, fresh IMU/init seeds60017/65003. Existing gates retained; segment errors in physical units are primary because one filename Hs cannot normalize both sea states.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(path.read_bytes()).hexdigest()),indent=2)+'\n')
print('Completed',len(rows))

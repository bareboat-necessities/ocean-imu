import sys,os,json,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from scipy.signal import welch,csd
ROOT=Path('/workspace/scratch/449eedbac964/ocean-imu')
sys.path.insert(0,str(ROOT/'tools'))
from model_mismatch_ablation import RECORDS,FAMILIES
from ou_validation import parse_validation_metrics
OUT=Path(__file__).resolve().parent/'selected-spectra-iii'
FAMILIES['OU-III']=Path(__file__).resolve().parent/'final-bin/kalman_ou_iii-sim'
def run(task):
 fam,i=task;r=RECORDS[i];folder=OUT/fam/r.spectrum;folder.mkdir(parents=True,exist_ok=True)
 inp=folder/r.filename
 if not inp.exists(): inp.symlink_to((FAMILIES[fam].parent/r.filename).resolve())
 binary=FAMILIES[fam];binary.chmod(0o755)
 env=dict(os.environ,W3D_WRITE_TIMESERIES='1',W3D_COLLECT_ALL_GATES='1',W3D_VALIDATION_WINDOW_SEC='900')
 q=subprocess.run([str(binary),'--input',str(inp)],capture_output=True,text=True,env=env,cwd=binary.parent)
 (folder/'run.log').write_text(q.stdout+q.stderr)
 if q.returncode not in (0,1): raise RuntimeError(q.stderr)
 path=next(folder.glob('w3d_*.csv'));data=np.genfromtxt(path,delimiter=',',names=True)
 data=data[data['time']>=300]
 row={'family':fam,'record':r.filename,'metrics':parse_validation_metrics(q.stdout),'axes':{}}
 for axis in 'xyz':
  ref=data['acc_ref_'+axis];est=data['acc_est_'+axis];err=est-ref
  f,p=welch(ref,fs=200,nperseg=16384);_,pe=welch(err,fs=200,nperseg=16384);_,po=welch(est,fs=200,nperseg=16384);_,cross=csd(ref,est,fs=200,nperseg=16384)
  peak=np.argmax(p);band=(f>=.05)&(f<=1);noise=(f>=2)&(f<=30)
  row['axes'][axis]={'ref_rms':float(np.sqrt(np.mean(ref**2))),'error_rms':float(np.sqrt(np.mean(err**2))),'error_mean':float(err.mean()),'peak_hz':float(f[peak]),'gain_at_peak':float(abs(cross[peak]/p[peak])),'phase_deg_at_peak':float(np.angle(cross[peak],deg=True)),'coherence_at_peak':float(abs(cross[peak])**2/(p[peak]*po[peak])),'wave_band_error_rms':float(np.sqrt(np.trapezoid(pe[band],f[band]))),'out_of_band_est_rms':float(np.sqrt(np.trapezoid(po[noise],f[noise])))}
  np.savez_compressed(folder/('acc_'+axis+'.npz'),f=f,ref=p,err=pe,estimate=po,cross=cross)
 row['tuning']={n:{'mean':float(data[n].mean()),'min':float(data[n].min()),'max':float(data[n].max())} for n in ('tau_applied','sigma_a_applied','R_p0_applied','freq_tracker_hz')}
 (folder/'spectra.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 return row
with ThreadPoolExecutor(4) as pool: rows=list(pool.map(run,[(fam,i) for fam in ('OU-III',) for i in (0,4)]))
(OUT/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import csv,math,re,shutil,zipfile
ROOT=Path(__file__).resolve().parent.parent/'ocean-imu';DOC=ROOT/'doc/kalman_ou_iii';RESULT=ROOT/'reports/results'
def read(path):
 with path.open() as f:return list(csv.DictReader(f))
rows={(r['family'],r['label']):r for r in read(RESULT/'engine_noise_degradation/engine_noise_summary.csv')}
guard={(r['condition'],r['guard']):r for r in read(RESULT/'engine_noise_mitigation/guard_summary.csv')}
p=DOC/'w3d-engine-noise-degradation.tex-part';s=p.read_text()
def offset(r):return math.sqrt(sum(float(r['disp_'+a+'_mean_m'])**2 for a in 'xyz'))
for family in ['OU-II','OU-III','TFG']:
 f=family.replace('-','--')
 for label,mode in [('engine off','off'),('speed 2400 rpm','on')]:
  r=rows[(family,label)];line=f"{f} & {mode} & {float(r['disp_3d_rms_m']):.3f} & {offset(r):.3f} & {float(r['pitch_rms_deg']):.3f} & {float(r['yaw_rms_deg']):.2f} "+r'\\'
  s=re.sub(r'^'+re.escape(f+' & '+mode+' & ')+r'.*$',lambda m:line,s,flags=re.M)
base=rows[('OU-III','engine off')];cruise=rows[('OU-III','speed 2400 rpm')]
start=s.index("OU--III's 3-D RMS rises");end=s.index('The accelerometer update',start)
prose=f"OU--III's 3-D RMS rises from "+rf"\SI{{{float(base['disp_3d_rms_m']):.3f}}}{{m}} to \SI{{{float(cruise['disp_3d_rms_m']):.3f}}}{{m}}, a factor of \num{{{float(cruise['disp_3d_rms_m'])/float(base['disp_3d_rms_m']):.2f}}}."+'\n'
prose+='Across families the offset fractions are '+', '.join(f.replace('-','--')+rf": \pct{{{100*offset(rows[(f,'speed 2400 rpm')])/float(rows[(f,'speed 2400 rpm')]['disp_3d_rms_m']):.1f}}}" for f in ['OU-II','OU-III','TFG'])+'.\n'
prose+='Static offset does not dominate both OU families.\nPitch RMS and pitch offset are '+rf"\SI{{{float(cruise['pitch_rms_deg']):.3f}}}{{\degree}} and \SI{{{abs(float(cruise['pitch_mean_deg'])):.3f}}}{{\degree}}."+'\n'
s=s[:start]+prose+s[end:]
gyro=max(abs(float(rows[(f,'accelerometer only')]['disp_3d_rms_m'])/float(rows[(f,'speed 2400 rpm')]['disp_3d_rms_m'])-1)*100 for f in ['OU-II','OU-III','TFG'])
s=re.sub(r'at most \\pct\{[0-9.]+\} across the families',lambda m:rf'at most \pct{{{gyro:.3f}}} across the families',s)
for f in ['OU-II','OU-III']:
 a=[float(rows[(f,x)]['disp_3d_rms_m']) for x in ['bandwidth 20 Hz','bandwidth 40 Hz','speed 2400 rpm','bandwidth 160 Hz']]
 b=[float(rows[(f,x)]['disp_3d_rms_m']) for x in ['matched 20 Hz','matched 40 Hz','speed 2400 rpm','matched 160 Hz']]
 line='For '+f.replace('-','--')+rf', the maximum/minimum 3-D spread falls from \num{{{max(a)/min(a):.2f}}} to \num{{{max(b)/min(b):.2f}}}.'
 s=re.sub('For '+re.escape(f.replace('-','--'))+r', the maximum/minimum 3-D spread[^\n]+',lambda m:line,s)
labels={'engine off':'Engine off','800 rpm':r'\SI{800}{rpm}','1600 rpm':r'\SI{1600}{rpm}','2400 rpm':r'\SI{2400}{rpm}','3200 rpm':r'\SI{3200}{rpm}','2400 rpm, quiet mount':'Quiet mount','2400 rpm, engine bed':'Engine bed','2400 rpm, wide sensor':'Wide sensor'}
b=float(guard[('engine off','off')]['disp_3d_rms_m'])
for cond,label in labels.items():
 rr=[guard[(cond,g)] for g in ['off','guard','guard+R']]
 values=[float(r['disp_3d_rms_m']) for r in rr]+[abs(float(r['pitch_mean_deg'])) for r in rr]+[float(rr[-1]['disp_3d_rms_m'])/b]
 line=label+' & '+' & '.join(f'{v:.3f}' for v in values)+' '+r'\\'
 s=re.sub('^'+re.escape(label+' & ')+r'.*$',lambda m:line,s,flags=re.M)
a=abs(float(guard[('800 rpm','guard')]['pitch_mean_deg']));b=abs(float(guard[('800 rpm','guard+R')]['pitch_mean_deg']))
s=re.sub(r'At \\SI\{800\}\{rpm\}, pitch offset rises from .*?with covariance inflation\.',lambda m:rf'At \SI{{800}}{{rpm}}, pitch offset rises from \SI{{{a:.3f}}}{{\degree}} to \SI{{{b:.3f}}}{{\degree}} with covariance inflation.',s,flags=re.S)
s=s.replace('$\\sqrt{\\sigma^2+(0.75 e)^2}$', '$\\sqrt{(w\\sigma)^2+(0.75 e)^2}$').replace('from the same gated detector excess $e$.','from the same gated detector excess $e$, after the low-wave multiplier $w$ of Sec.~\\ref{sec:low-wave-noise-weighting}.')
p.write_text(s)
p=DOC/'w3d-model-mismatch-ablation.tex-part';s=p.read_text()
for r in read(RESULT/'model_mismatch_ablation/model_mismatch_summary.csv'):
 f=r['family'].replace('-','--');line=f+' & '+' & '.join(f"{float(r[k]):.3f}" for k in ['disp_x_rms_m','disp_y_rms_m','disp_z_rms_m','disp_3d_rms_m'])+f" & {float(r['disp_z_pct_refrms']):.2f} "+r'\\'
 s=re.sub(r'^\s*'+re.escape(f+' & ')+r'.*$',lambda m:'    '+line,s,flags=re.M)
p.write_text(s)
for source,target in [('ou_rs_law/ou_rs_roundtrip_scores.tex','w3d-roundtrip-transition-scores-generated.tex-part'),('ou3_reduced_mse/reduced_mse.tex','w3d-reduced-mse-results-generated.tex-part')]:shutil.copyfile(RESULT/source,DOC/target)
z=zipfile.ZipFile(ROOT.parent/'low-wave-study/engine-ci.zip');dest='reports/results/engine_noise_mitigation/family_guard_report.txt';(ROOT/dest).write_bytes(z.read(dest))

from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
out=p.parent/'ocean-imu/reports/results/low_wave_noise'
fig,axes=plt.subplots(2,2,figsize=(10,6.6),sharex=True,sharey=True,layout='constrained')
for row,fam in enumerate(['OU-II','OU-III']):
 for col,axname in enumerate(['x','y']):
  ax=axes[row,col]
  for d,label,color in [('baseline-spectra','PR head 121a154','#728090'),('selected-spectra','Selected weighting','#007d85')]:
   data=np.load(p/d/fam/'JONSWAP'/('acc_'+axname+'.npz'))
   ax.loglog(data['f'][1:],np.sqrt(data['err'][1:]),label=label,color=color,lw=1.2,alpha=.9)
  ax.axvspan(.05,1,color='#7c96b0',alpha=.09)
  ax.set_title(f'{fam} · {axname.upper()} acceleration error',loc='left',fontsize=11)
  ax.set_xlim(.05,30);ax.set_ylim(1e-5,.03);ax.grid(True,which='major',alpha=.15)
  if row==1:ax.set_xlabel('Frequency (Hz)')
  if col==0:ax.set_ylabel('Error ASD (m/s² / √Hz)')
axes[0,0].legend(frameon=False,fontsize=9)
fig.suptitle('Low-wave acceleration: reduced broadband noise with a wave-band tradeoff',fontsize=13)
fig.savefig(out/'acceleration-error-spectra.png',dpi=170)

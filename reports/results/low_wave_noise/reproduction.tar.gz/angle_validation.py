"""Paired replays at new hull-relative angles and world headings, unchanged gates."""
import argparse,hashlib,json,os,re,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['direction','snr'],required=True);p.add_argument('--jobs',type=int,default=8);a=p.parse_args()
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent/'ocean-imu';sys.path.insert(0,str(ROOT/'tools'))
from ou_validation import parse_validation_metrics
OUT=BASE/('angle-'+a.mode);OUT.mkdir(exist_ok=True)
paths=sorted(list((BASE/'heading-records').glob('*/*wave_data*.csv'))+list((BASE/'relative-angle-records').glob('*/*wave_data*.csv')))
folder=BASE/('frequency-bin' if a.mode=='direction' else 'snr-bin')
binaries={f:folder/('kalman_ou_'+f.lower().split('-')[1]+'-sim') for f in ['OU-II','OU-III']}
for b in binaries.values(): b.chmod(0o755)
configs=[('current',{}),('candidate',{'SF_DIAGNOSTIC_DIRECTION_INPUT':'1'} if a.mode=='direction' else {'SF_LOW_WAVE_RACC_MAX_SCALE':'4','SF_LOW_WAVE_RACC_SNR':'2'})]
def run(task):
 family,path,(config,knobs)=task;b=binaries[family]
 env=dict(os.environ,W3D_WRITE_TIMESERIES='0',W3D_COLLECT_ALL_GATES='1',W3D_VALIDATION_WINDOW_SEC='900',W3D_INIT_SEED='53017',W3D_IMU_SEED='53017',**knobs)
 q=subprocess.run([str(b),'--input',str(path)],cwd=b.parent,env=env,capture_output=True,text=True)
 key=family+'_'+path.parent.parent.name+'_'+path.parent.name+'_'+path.stem+'_'+config
 (OUT/(key+'.log')).write_text(q.stdout+q.stderr)
 if q.returncode not in (0,1) or (q.returncode==1 and 'QUALITY_GATE: PASS=0' not in q.stdout):raise RuntimeError(key+q.stderr[-1000:])
 row=dict(family=family,record=str(path.relative_to(BASE)),config=config,env=knobs,seed='53017',exit_code=q.returncode,metrics=parse_validation_metrics(q.stdout),violations=[s for s in q.stdout.splitlines() if s.startswith('ERROR:')])
 (OUT/(key+'.json')).write_text(json.dumps(row,indent=2));return row
rows=[]
with ThreadPoolExecutor(a.jobs) as pool:
 for f in as_completed([pool.submit(run,t) for t in [(f,p,c) for f in binaries for p in paths for c in configs]]):
  row=f.result();rows.append(row);print(len(rows),row['family'],row['record'],row['config'],flush=True)
(OUT/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps(dict(protocol='16 full records x two OU families x paired baseline/candidate; new IMU/initialization seed 53017; final 900 seconds; unchanged gates. Eight rigid world rotations and eight independently recomputed hull responses at new incident angles. Same prescribed harmonic phases, not new stochastic sea realizations.',configs=configs,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),binary_sha256={f:hashlib.sha256(b.read_bytes()).hexdigest() for f,b in binaries.items()},input_sha256={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}),indent=2)+'\n')

#define main upstream_main
#include "/workspace/scratch/449eedbac964/oceanography-waves-lib-v121/data-sim/waves_sim.cpp"
#undef main
int main(int argc, char** argv) {
  const float angle=std::stof(argv[1]);
  for(int index : {0, 3}) {
    auto wp=waveParamsList[index]; wp.direction=angle;
    for(auto type : {WaveType::JONSWAP, WaveType::PMSTOKES})
      run_vessel_scenario(type,wp,1200.0);
  }
}

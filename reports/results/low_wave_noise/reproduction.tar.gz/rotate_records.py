"""Rigid heading rotation: same relative sea/hull response, fixed magnetic north."""
from pathlib import Path
import sys,json,hashlib,re
import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation
ROOT=Path('/workspace/scratch/449eedbac964/ocean-imu');sys.path.insert(0,str(ROOT/'tools'))
from model_mismatch_ablation import RECORDS,FAMILIES
OUT=Path(__file__).resolve().parent/'heading-records';OUT.mkdir(exist_ok=True)
rows=[]
for i in (0,3,4,7):
 rec=RECORDS[i];src=(FAMILIES['OU-III'].parent/rec.filename).resolve();data=pd.read_csv(src)
 qnames=['q_wb_zu_x','q_wb_zu_y','q_wb_zu_z','q_wb_zu_w']
 q=Rotation.from_quat(data[qnames].to_numpy())
 for angle in (-60.,75.):
  rot=Rotation.from_euler('z',angle,degrees=True);d=data.copy()
  for kind in ('disp','vel','acc'):
   names=[f'{kind}_{a}' for a in 'xyz'];d[names]=rot.apply(data[names].to_numpy())
  updated=q*rot.inv();d[qnames]=updated.as_quat()
  d[['roll_deg','pitch_deg','yaw_deg']]=updated.inv().as_euler('xyz',degrees=True)
  original=float(re.search(r'_A([-.0-9]+)_',rec.filename)[1]);direction=(original+angle+180)%360-180
  name=re.sub(r'_A[-.0-9]+_',f'_A{direction:.2f}_',rec.filename)
  folder=OUT/str(int(angle));folder.mkdir(exist_ok=True);dst=folder/name
  d.to_csv(dst,index=False,float_format='%.9g')
  # Rotating both inertial vectors and world attitude leaves the body's
  # ideal accelerometer/gyro stream unchanged, up to original CSV precision.
  pred=updated.apply(d[['acc_x','acc_y','acc_z']].to_numpy()+[0,0,9.80665])
  error=float(np.max(np.abs(pred-d[['acc_bx','acc_by','acc_bz']].to_numpy())))
  rows.append(dict(input=str(dst),source=rec.filename,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),heading_rotation_deg=angle,body_force_consistency_max_mps2=error))
  print(name,'body error',error,flush=True)
(OUT/'manifest.json').write_text(json.dumps({'method':__doc__,'records':rows},indent=2)+'\n')

import csv,gzip,hashlib,json,shutil,subprocess,tarfile,io
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent/'ocean-imu';OUT=ROOT/'reports/results/low_wave_noise';OUT.mkdir(parents=True,exist_ok=True)
rows=[];manifests={};summary=[]
for folder in sorted(BASE.iterdir()):
 if not folder.is_dir() or not (folder/'runs.json').exists():continue
 name=folder.name
 if name in ['noop-rejection']:continue
 source=json.loads((folder/'runs.json').read_text())
 for row in source:
  row=dict(row,study=name)
  if name=='ou2-bias' and 'OU_II_ACC_BIAS_TAU_SEC' in row.get('env',{}):row['invalid_arm']='Variable not exposed by executable; ignored. This is not a bias-tau ablation.'
  if name=='direction-sweep':row['axis_metric_limitation']='Unavailable zero axes were scored as zero-degree bearings; use subsequent direction-frequency/angle studies for conditional axis accuracy.'
  rows.append(row)
 if (folder/'manifest.json').exists():manifests[name]=json.loads((folder/'manifest.json').read_text())
 if (folder/'summary.json').exists():
  for item in json.loads((folder/'summary.json').read_text()):summary.append(dict(study=name,**item))
# Prior targeted yaw/noise-floor work is evidence for the rejected tuning axes.
for folder in sorted((BASE.parent/'noise-yaw-study').iterdir()):
 if not folder.is_dir() or not (folder/'runs.json').exists():continue
 name='yaw-noise/'+folder.name
 for row in json.loads((folder/'runs.json').read_text()):rows.append(dict(row,study=name))
 if (folder/'manifest.json').exists():manifests[name]=json.loads((folder/'manifest.json').read_text())
 if (folder/'summary.json').exists():
  for item in json.loads((folder/'summary.json').read_text()):summary.append(dict(study=name,**item))
with (OUT/'runs.jsonl.gz').open('wb') as dest:
 with gzip.GzipFile(filename='',mode='wb',fileobj=dest,mtime=0) as z:
  for r in rows:z.write((json.dumps(r,separators=(',',':'))+'\n').encode())
(OUT/'screen-summaries.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'study-manifests.json').write_text(json.dumps(manifests,indent=2)+'\n')
source=OUT/'reproduction';source.mkdir(exist_ok=True)
for name in ['screen-producer.py','candidate-producer.py','candidate-source.patch','snr-source.patch','snr-noise-weighting.h','angle_validation.py','new_angle.cpp','rotate_records.py','baseline_spectra.py','package_evidence.py','low_transition.py','plot_spectra.py','selected_spectra.py','selected_spectra_iii.py','sync_auxiliary_paper.py']:
 shutil.copyfile(BASE/name,source/name)
for d in ['candidate-bin','snr-bin','final-bin']:
 shutil.copyfile(BASE/d/'build-provenance.json',source/(d+'-provenance.json'))
for d in ['direction-include','frequency-include']:
 target=source/d
 shutil.copytree(BASE/d,target,dirs_exist_ok=True)
shutil.copyfile(BASE.parent/'noise-yaw-study/magnetic-error-diagnostic.json',OUT/'magnetic-error-diagnostic.json')
shutil.copyfile(BASE/'baseline-spectra/summary.json',OUT/'baseline-spectra.json')
for d in ['baseline-spectra','selected-spectra']:
 if (BASE/d/'summary.json').exists():shutil.copyfile(BASE/d/'summary.json',OUT/(d+'.json'))
shutil.copyfile(BASE/'spectral-comparison.csv',OUT/'spectral-comparison.csv')
(source/'README.txt').write_text("Historical instrumentation is archived as evidence, not active project source. Baseline source is 121a154c9024dcce755d8b8ebbf39c1f7da92b33. Apply candidate-source.patch or snr-source.patch to that checkout; the latter additionally needs snr-noise-weighting.h copied to src/wave_dir/VesselRaoNoiseWeighting.h. Build O2 with the flags in each binary provenance file and an Eigen include path, then use the manifest configurations and pinned records with rao_parameter_tuning.py. Header overlays preserve the direction-only diagnostic variants. Path literals in archived scripts require relocation. The final-bin provenance identifies the shipping O3 objects, independently linked and verified byte-identical to make-produced simulators. Latest-source comparison uses SF_LOW_WAVE_RACC_MAX_SCALE=1 for the off arm and no overrides for selected.\n")
with (OUT/'reproduction.tar.gz').open('wb') as dest:
 with gzip.GzipFile(filename='',mode='wb',fileobj=dest,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for item in sorted(source.rglob('*')):
    if not item.is_file():continue
    data=item.read_bytes();info=tarfile.TarInfo(str(item.relative_to(source)));info.size=len(data);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(data))
shutil.rmtree(source)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=dict(selected_source='9de0543507509cabb478b751b83bf5c74711764d',baseline_source='121a154c9024dcce755d8b8ebbf39c1f7da92b33',rows=len(rows),valid_rows=sum('invalid_arm' not in x for x in rows),studies=len(manifests),files={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['manifest.json','study.md']},protocol='Training default/11/23, first fresh 17011/19001/23003/29009 for rejected global weighting/R_S, locked SNR candidate fresh 31013/37003/41011/47017, angle check 53017. Final default O3 pairs verify shipping source. All full 1200 s; score final 900 s; unchanged gates.',limitations=['Screen manifests identify binary bytes; their parent source commit alone does not reproduce uncommitted instrumentation. Source snapshots/patches are provided; path literals in scratch reproduction scripts require relocation.','O2 screens were used to reduce compile cost. Final shipping O3 checks are recorded separately.','Twelve OU-II bias-tau arms are invalid because the variable was unsupported; later runner rejects this condition.','First direction sweep zero-axis statistics and earlier OU-III applied-parameter CSV columns have the stated semantic limitations.','Angle runner violation lists were reconstructed from retained combined stdout/stderr logs; metrics and exit codes unchanged.','Rotated and new-angle records retain the prescribed harmonic phases; no claim of independent stochastic sea or different-hull validation.'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['python3',str(ROOT/'tools/low_wave_report.py')],check=True)
with (OUT/'study.md').open('a') as f:
 f.write("\nThe shipping O3 checks retain 6/8 passing records in each OU family: six violations in OU-II and two in OU-III, all in the two 8.5 m records. O3 simulator copies are byte-identical to the Makefile outputs. Across the default low-wave spectral checks, horizontal peak gain is 0.916–0.980 after weighting; phase magnitude stays below 2.8 degrees. Broadband error falls, but X wave-band error increases and peak gain loses roughly 1–2.5 percentage points. The full per-axis comparison is in spectral-comparison.csv. The PNG shows the JONSWAP Hs=0.27 m error spectra over the final 900 seconds.\n\nThe additional Hs 0.27→1.5→0.27 surrogate uses kinematically closed 120-second transitions and two fresh sensor draws. Neither family adds a quality violation (OU-II 5, OU-III 6 across two cases each). Low-return 3-D acceleration RMS falls about 15% in OU-II and 10% in OU-III; mean pitch increases, and OU-III displacement during the rising transition increases about 3%. These are transition tradeoffs, not uniform improvement or a new gate certification.\n")
print(json.dumps({'rows':len(rows),'studies':len(manifests),'bytes':sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())}))
